// ============================================================
// JELAJAHNESIA WHATSAPP AI CONNECTOR
// Node.js + Baileys — Deploy di Railway
// ============================================================

const { default: makeWASocket, useMultiFileAuthState, 
        DisconnectReason, fetchLatestBaileysVersion } = require('@whiskeysockets/baileys');
const { Boom } = require('@hapi/boom');
const express  = require('express');
const axios    = require('axios');
const pino     = require('pino');
const fs       = require('fs');
const path     = require('path');

// ── KONFIGURASI ─────────────────────────────────────────────
const CONFIG = {
  // URL webhook WordPress kamu
  WP_WEBHOOK_URL: process.env.WP_WEBHOOK_URL || 'https://jelajahnesia.id/wp-json/ai-analyzer/v1/webhook',
  
  // Secret key (harus sama dengan di plugin WordPress)
  WEBHOOK_SECRET: process.env.WEBHOOK_SECRET || 'jelajahnesia2024secret',
  
  // Port untuk Railway
  PORT: process.env.PORT || 3000,
  
  // Filter: abaikan pesan dari grup?
  IGNORE_GROUPS: process.env.IGNORE_GROUPS !== 'false',
  
  // Minimal panjang pesan untuk dikirim ke AI
  MIN_MESSAGE_LENGTH: 3,
};

// ── EXPRESS SERVER (untuk health check Railway) ──────────────
const app = express();
app.use(express.json());

app.get('/', (req, res) => {
  res.json({ 
    status: 'online', 
    service: 'Jelajahnesia WA Connector',
    uptime: Math.floor(process.uptime()) + 's'
  });
});

app.get('/health', (req, res) => res.json({ status: 'ok' }));

app.listen(CONFIG.PORT, () => {
  console.log(`✅ Server berjalan di port ${CONFIG.PORT}`);
});

// ── BAILEYS WHATSAPP CONNECTION ──────────────────────────────
async function startWhatsApp() {
  // Simpan session auth
  const authFolder = path.join(__dirname, 'auth_info');
  if (!fs.existsSync(authFolder)) fs.mkdirSync(authFolder, { recursive: true });

  const { state, saveCreds } = await useMultiFileAuthState(authFolder);
  const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    version,
    auth: state,
    logger: pino({ level: 'silent' }), // silent = tidak spam log
    printQRInTerminal: true,            // QR code muncul di Railway logs
    browser: ['Jelajahnesia AI', 'Chrome', '1.0'],
    markOnlineOnConnect: false,
  });

  // ── SIMPAN CREDENTIALS ──────────────────────────────────────
  sock.ev.on('creds.update', saveCreds);

  // ── HANDLE KONEKSI ──────────────────────────────────────────
  sock.ev.on('connection.update', ({ connection, lastDisconnect, qr }) => {
    if (qr) {
      console.log('\n📱 SCAN QR CODE INI DI WHATSAPP:');
      console.log('Buka WhatsApp → Perangkat Tertaut → Tautkan Perangkat\n');
    }

    if (connection === 'close') {
      const shouldReconnect = (lastDisconnect?.error instanceof Boom)
        ? lastDisconnect.error.output.statusCode !== DisconnectReason.loggedOut
        : true;

      console.log('⚠️ Koneksi terputus. Reconnect:', shouldReconnect);
      if (shouldReconnect) setTimeout(startWhatsApp, 5000);
    }

    if (connection === 'open') {
      console.log('✅ WhatsApp terhubung! Siap terima pesan.');
    }
  });

  // ── HANDLE PESAN MASUK ──────────────────────────────────────
  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return;

    for (const msg of messages) {
      try {
        // Skip pesan dari diri sendiri
        if (msg.key.fromMe) continue;

        // Skip pesan lama (lebih dari 30 detik)
        const msgTime = msg.messageTimestamp * 1000;
        if (Date.now() - msgTime > 30000) continue;

        const isGroup = msg.key.remoteJid?.endsWith('@g.us') || false;

        // Filter grup
        if (CONFIG.IGNORE_GROUPS && isGroup) continue;

        // Ekstrak isi pesan
        const body = extractMessageText(msg);
        if (!body || body.length < CONFIG.MIN_MESSAGE_LENGTH) continue;

        // Ekstrak info pengirim
        const from = isGroup
          ? msg.key.participant?.replace('@s.whatsapp.net', '')
          : msg.key.remoteJid?.replace('@s.whatsapp.net', '');

        const pushName = msg.pushName || '';

        console.log(`📨 Pesan dari ${pushName || from}: "${body.substring(0, 50)}${body.length > 50 ? '...' : ''}"`);

        // Kirim ke WordPress
        await sendToWordPress({
          id: msg.key.id,
          from: from,
          to: sock.user?.id?.split(':')[0] || '',
          pushName: pushName,
          body: body,
          isGroup: isGroup,
          direction: 'in',
          timestamp: msg.messageTimestamp,
        });

      } catch (err) {
        console.error('Error proses pesan:', err.message);
      }
    }
  });
}

// ── EKSTRAK TEKS DARI BERBAGAI TIPE PESAN ───────────────────
function extractMessageText(msg) {
  const m = msg.message;
  if (!m) return null;

  return m.conversation
    || m.extendedTextMessage?.text
    || m.imageMessage?.caption
    || m.videoMessage?.caption
    || m.documentMessage?.caption
    || m.buttonsResponseMessage?.selectedDisplayText
    || m.listResponseMessage?.title
    || null;
}

// ── KIRIM KE WORDPRESS WEBHOOK ───────────────────────────────
async function sendToWordPress(payload) {
  try {
    const res = await axios.post(CONFIG.WP_WEBHOOK_URL, payload, {
      headers: {
        'Content-Type': 'application/json',
        'X-Webhook-Secret': CONFIG.WEBHOOK_SECRET,
      },
      timeout: 15000,
    });
    console.log(`✅ Terkirim ke WordPress: ${res.status}`);
  } catch (err) {
    console.error('❌ Gagal kirim ke WordPress:', err.message);
  }
}

// ── START ────────────────────────────────────────────────────
startWhatsApp().catch(err => {
  console.error('Fatal error:', err);
  process.exit(1);
});
